# Load necessary libraries
library(tseries)
library(forecast)
library(ggplot2)

# Time and cases data
time_data <- c("30.03.2022", "30.06.2022", "30.09.2022", "30.12.2022", 
               "30.03.2023", "30.06.2023", "30.09.2023", "30.12.2023", 
               "30.03.2024", "30.06.2024")
cases_data <- c(10348, 18903, 43574, 99841, 126998, 154188, 180895, 205949, 245969, 321394)

# Convert time_data to Date format and create a time series object
time_data <- as.Date(time_data, format="%d.%m.%Y")
cases_ts <- ts(cases_data, start=c(2022, 3), frequency=4)  # Quarterly data

# Plot the original time series
plot(cases_ts, main="Monkeypox Cases Time Series", ylab="Cases", xlab="Time", col="blue")

# Perform Augmented Dickey-Fuller Test (ADF) for stationarity
adf_test <- adf.test(cases_ts)

# Print ADF Test result
print(adf_test)

# Plot ACF and PACF for the original time series
acf(cases_ts, main="ACF of Monkeypox Cases")
pacf(cases_ts, main="PACF of Monkeypox Cases")

# Differencing the data if non-stationary (if p-value > 0.05)
if (adf_test$p.value > 0.05) {
  cases_diff <- diff(cases_ts)
  
  # Plot the differenced time series
  plot(cases_diff, main="Differenced Monkeypox Cases Time Series", ylab="Differenced Cases", xlab="Time", col="orange")
  
  # Plot ACF and PACF for differenced data
  acf(cases_diff, main="ACF of Differenced Monkeypox Cases")
  pacf(cases_diff, main="PACF of Differenced Monkeypox Cases")
}

# Fit an ARIMA model (after differencing if needed)
fit <- auto.arima(cases_ts)
summary(fit)

# Check residuals of the fitted model
checkresiduals(fit)

# Forecast future values (for next 4 quarters)
forecasted_values <- forecast(fit, h=4)
plot(forecasted_values, main="Forecast of Monkeypox Cases", ylab="Cases")

# Display the forecasted values
print(forecasted_values)
